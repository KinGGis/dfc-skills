# Migration des skills DFC vers GitHub (pour qu'ils se chargent dans les agents)

Constat DFC-OPS-001: l'adaptateur Codex ne charge que les skills d'origine GitHub
ou bundled. Les skills crees dans Studio ("Paperclip workspace") s'affichent actives
mais n'atteignent pas le runtime de l'agent. Ces trois-la etaient dans ce cas:
dfc-parametres, dfc-regime-collecte, dfc-document-production. On les met dans le
depot GitHub kinggis/dfc-skills pour qu'ils se chargent comme les skills de role.

Chaque dossier ici contient un SKILL.md sans script (import non bloque).

## 1. Pousser dans le depot

Depuis ta copie locale du depot kinggis/dfc-skills, copie les trois dossiers a la
racine (a cote de dfc-regime-analyst, dfc-portfolio-manager, etc.):

    dfc-parametres/SKILL.md
    dfc-regime-collecte/SKILL.md
    dfc-document-production/SKILL.md

Puis:

    git add dfc-parametres dfc-regime-collecte dfc-document-production
    git commit -m "Ajout skills DFC parametres, regime-collecte, document-production (sans script)"
    git push

## 2. Importer dans Paperclip

Repo prive: passe-le public deux minutes (comme la derniere fois), importe, repasse
prive. Importe chaque skill par URL de sous-dossier, exactement comme les skills de
role:

    https://github.com/KinGGis/dfc-skills/tree/main/dfc-parametres
    https://github.com/KinGGis/dfc-skills/tree/main/dfc-regime-collecte
    https://github.com/KinGGis/dfc-skills/tree/main/dfc-document-production

## 3. Remplacer les anciennes versions "workspace"

Il y a maintenant deux exemplaires de chaque (l'ancien Studio + le nouveau GitHub).
Pour eviter toute ambiguite:
- Desactive puis supprime les versions "Paperclip workspace" de dfc-parametres,
  dfc-regime-collecte et dfc-document-production.
- Active les versions GitHub sur les bons agents: dfc-parametres sur CIO, Research,
  RiskOfficer; dfc-regime-collecte sur Research; dfc-document-production sur CIO et
  Research.

## 4. Verifier le chargement

Relance la tache de sonde (DFC-11, section A) sur le CIO: la liste des skills doit
maintenant inclure dfc-parametres et dfc-document-production. Tant que ce n'est pas
le cas, ils ne sont pas reellement en vigueur, quelle que soit l'interface.

Note: dfc-document-production appelle le service de rendu via les secrets
DFC_RENDER_URL et DFC_RENDER_TOKEN (voir le paquet du service). Tant que le service
n'est pas expose et les secrets poses, l'agent livrera le pack de contenu et
signalera l'indisponibilite, sans improviser de charte.

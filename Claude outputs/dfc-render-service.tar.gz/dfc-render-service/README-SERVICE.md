# Service de rendu documentaire DFC - deploiement VPS

Le moteur (/opt/dfc/brand-engine) est expose comme service HTTP local, puis publie
en HTTPS via le reverse-proxy qui sert deja le domaine. L'agent envoie un pack de
contenu, recoit le PDF a la charte.

## 1. Installer le service (en root)

Depose render_service.py, dfc-render.service et install_service.sh dans
/opt/dfc/brand-engine (a cote de render_doc.py), puis:

    cd /opt/dfc/brand-engine
    bash install_service.sh

Le script installe Flask, cree un fichier .env avec un JETON aleatoire
(DFC_RENDER_TOKEN), installe et demarre le service systemd dfc-render, et teste
/health en local. Il affiche le jeton a la fin: note-le, il ira dans les Secrets
Paperclip.

Verifs utiles:
    systemctl status dfc-render
    curl -s http://127.0.0.1:8477/health      # -> {"status":"ok"}

## 2. Exposer en HTTPS (l'agent n'atteint que le 443 du domaine)

L'agent joint https://mediumpurple-pony-613782.hostingersite.com (443) mais PAS un
port arbitraire ni le localhost du VPS. Il faut donc publier le service sous le
domaine, en 443, via le serveur web qui est deja devant Paperclip.

D'abord, identifier ce serveur web (une seule commande, colle-moi la sortie):

    ss -tlnp | grep ':443' ; echo '---' ; \
    ls /etc/nginx 2>/dev/null ; which caddy nginx apache2 2>/dev/null ; \
    docker ps --format '{{.Names}} {{.Image}} {{.Ports}}' 2>/dev/null

Selon le resultat, on ajoute une route /dfc-render -> 127.0.0.1:8477/render.

Exemple pour nginx (a inserer dans le server { } du domaine, puis nginx -t && systemctl reload nginx):

    location = /dfc-render {
        proxy_pass http://127.0.0.1:8477/render;
        proxy_set_header Host $host;
        client_max_body_size 5m;
        proxy_read_timeout 120s;
    }

L'URL de service devient alors:
    https://mediumpurple-pony-613782.hostingersite.com/dfc-render

Si Paperclip est servi par Caddy ou tourne en conteneur Docker, la route s'ecrit
differemment: envoie-moi la sortie de la commande ci-dessus et je te donne le bloc
exact.

## 3. Cote Paperclip (secrets des agents)

Ajouter, sur les agents qui produisent des documents (CIO, Research), deux secrets:
    DFC_RENDER_URL   = https://mediumpurple-pony-613782.hostingersite.com/dfc-render
    DFC_RENDER_TOKEN = <le jeton affiche par install_service.sh>

Le skill dfc-document-production les lit pour appeler le service.

## 4. Test de bout en bout

Depuis le VPS (verifie le chemin complet, jeton inclus):

    curl -sS -X POST https://mediumpurple-pony-613782.hostingersite.com/dfc-render \
      -H "Authorization: Bearer <jeton>" \
      -H "Content-Type: application/x-yaml" \
      --data-binary @/opt/dfc/brand-engine/example_pack.yaml \
      -o /tmp/test_service.pdf -w "%{http_code}\n"

Code 200 + PDF non vide = service pret. Ensuite, une tache d'agent qui appelle le
service confirme la boucle complete.

## Securite

Le service ecoute en local (127.0.0.1) et n'est atteignable que via le proxy HTTPS,
jamais en clair. Le jeton est dans .env (chmod 600) et dans les Secrets Paperclip,
jamais dans le code ni dans un depot. Le service ne fait que rendre un PDF a partir
d'un pack; il n'engage aucun capital et ne touche a aucune donnee du fonds.

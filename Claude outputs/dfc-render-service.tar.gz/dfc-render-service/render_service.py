#!/usr/bin/env python3
"""
DFC brand engine - service HTTP de rendu documentaire.

POST /render
  Auth: header  Authorization: Bearer <DFC_RENDER_TOKEN>
  Corps: un pack de contenu DFC-CONTENT-PACK v1 (YAML ou JSON), brut.
  Reponse: application/pdf (le document a la charte) ou une erreur JSON.

GET /health -> {"status":"ok"} (sans auth), pour la supervision.

Config par variables d'environnement:
  DFC_RENDER_TOKEN  (obligatoire) jeton partage attendu dans l'en-tete Authorization.
  DFC_RENDER_HOST   (defaut 127.0.0.1)
  DFC_RENDER_PORT   (defaut 8477)

Les requetes sont serialisees (un rendu a la fois) car le moteur reutilise un
repertoire de travail commun; suffisant pour le volume DFC. Logos embarques
(assets_b64), fusion PDF en Python (pikepdf), aucune dependance externe au rendu.
"""
import os, tempfile, threading, pathlib, traceback
from flask import Flask, request, send_file, jsonify
import render_doc  # meme dossier: /opt/dfc/brand-engine

TOKEN = os.environ.get("DFC_RENDER_TOKEN", "")
HOST = os.environ.get("DFC_RENDER_HOST", "127.0.0.1")
PORT = int(os.environ.get("DFC_RENDER_PORT", "8477"))

app = Flask(__name__)
_lock = threading.Lock()


@app.get("/health")
def health():
    return jsonify(status="ok")


@app.post("/render")
def render():
    # Auth
    if not TOKEN:
        return jsonify(error="service mal configure: DFC_RENDER_TOKEN absent"), 500
    auth = request.headers.get("Authorization", "")
    if auth != f"Bearer {TOKEN}":
        return jsonify(error="non autorise"), 401

    raw = request.get_data(as_text=True)
    if not raw or not raw.strip():
        return jsonify(error="corps vide: fournir un pack DFC-CONTENT-PACK v1"), 400

    with _lock:
        with tempfile.TemporaryDirectory() as d:
            pack_path = os.path.join(d, "pack.yaml")
            out_path = os.path.join(d, "out.pdf")
            pathlib.Path(pack_path).write_text(raw, encoding="utf-8")
            try:
                render_doc.run(pack_path, out_path)
            except Exception as e:
                return jsonify(error="echec du rendu",
                               detail=str(e),
                               trace=traceback.format_exc()[-2000:]), 422
            if not os.path.exists(out_path) or os.path.getsize(out_path) == 0:
                return jsonify(error="rendu vide"), 422
            return send_file(out_path, mimetype="application/pdf",
                             as_attachment=True, download_name="document_dfc.pdf")


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("DFC_RENDER_TOKEN non defini. Exporte-le avant de lancer le service.")
    app.run(host=HOST, port=PORT)

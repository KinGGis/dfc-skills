#!/usr/bin/env bash
# DFC brand engine - installe le service de rendu HTTP sur le VPS.
# Prerequis: le moteur est deja en place dans /opt/dfc/brand-engine avec son .venv
# (via install.sh). A lancer en root.
set -e
cd /opt/dfc/brand-engine

echo "[DFC] dependance Flask ..."
./.venv/bin/pip install -q flask

# Jeton partage: genere UNE fois, jamais affiche en clair ailleurs.
if [ ! -f .env ]; then
  TOKEN="$(openssl rand -hex 32)"
  umask 077
  printf 'DFC_RENDER_TOKEN=%s\nDFC_RENDER_HOST=127.0.0.1\nDFC_RENDER_PORT=8477\n' "$TOKEN" > .env
  chmod 600 .env
  echo "[DFC] .env cree avec un nouveau jeton (chmod 600)."
else
  echo "[DFC] .env existant conserve."
fi

echo "[DFC] service systemd ..."
cp dfc-render.service /etc/systemd/system/dfc-render.service
systemctl daemon-reload
systemctl enable dfc-render
systemctl restart dfc-render
sleep 2
systemctl --no-pager --full status dfc-render | head -n 12 || true

echo "[DFC] test local /health ..."
curl -s http://127.0.0.1:8477/health; echo
echo
echo "[DFC] Jeton a reporter dans les Secrets Paperclip (DFC_RENDER_TOKEN):"
grep DFC_RENDER_TOKEN .env
echo "[DFC] OK. Service en ecoute sur 127.0.0.1:8477. Voir README-SERVICE.md pour l'exposition HTTPS."
